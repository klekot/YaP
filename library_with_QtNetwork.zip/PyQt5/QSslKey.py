# encoding: utf-8
# module PyQt5.QtNetwork
# from C:\Python34\lib\site-packages\PyQt5\QtNetwork.pyd
# by generator 1.136
# no doc

# imports
import PyQt5.QtCore as __PyQt5_QtCore


class QSslKey(): # skipped bases: <class 'sip.simplewrapper'>
    """
    QSslKey()
    QSslKey(QByteArray, QSsl.KeyAlgorithm, QSsl.EncodingFormat encoding=QSsl.Pem, QSsl.KeyType type=QSsl.PrivateKey, QByteArray passPhrase=QByteArray())
    QSslKey(QIODevice, QSsl.KeyAlgorithm, QSsl.EncodingFormat encoding=QSsl.Pem, QSsl.KeyType type=QSsl.PrivateKey, QByteArray passPhrase=QByteArray())
    QSslKey(sip.voidptr, QSsl.KeyType type=QSsl.PrivateKey)
    QSslKey(QSslKey)
    """
    def algorithm(self): # real signature unknown; restored from __doc__
        """ QSslKey.algorithm() -> QSsl.KeyAlgorithm """
        pass

    def clear(self): # real signature unknown; restored from __doc__
        """ QSslKey.clear() """
        pass

    def handle(self): # real signature unknown; restored from __doc__
        """ QSslKey.handle() -> sip.voidptr """
        pass

    def isNull(self): # real signature unknown; restored from __doc__
        """ QSslKey.isNull() -> bool """
        return False

    def length(self): # real signature unknown; restored from __doc__
        """ QSslKey.length() -> int """
        return 0

    def swap(self, QSslKey): # real signature unknown; restored from __doc__
        """ QSslKey.swap(QSslKey) """
        pass

    def toDer(self, QByteArray_passPhrase=None, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
        """ QSslKey.toDer(QByteArray passPhrase=QByteArray()) -> QByteArray """
        pass

    def toPem(self, QByteArray_passPhrase=None, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
        """ QSslKey.toPem(QByteArray passPhrase=QByteArray()) -> QByteArray """
        pass

    def type(self): # real signature unknown; restored from __doc__
        """ QSslKey.type() -> QSsl.KeyType """
        pass

    def __eq__(self, *args, **kwargs): # real signature unknown
        """ Return self==value. """
        pass

    def __ge__(self, *args, **kwargs): # real signature unknown
        """ Return self>=value. """
        pass

    def __gt__(self, *args, **kwargs): # real signature unknown
        """ Return self>value. """
        pass

    def __init__(self, *__args): # real signature unknown; restored from __doc__ with multiple overloads
        pass

    def __le__(self, *args, **kwargs): # real signature unknown
        """ Return self<=value. """
        pass

    def __lt__(self, *args, **kwargs): # real signature unknown
        """ Return self<value. """
        pass

    def __ne__(self, *args, **kwargs): # real signature unknown
        """ Return self!=value. """
        pass

    __weakref__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """list of weak references to the object (if defined)"""


    __hash__ = None


