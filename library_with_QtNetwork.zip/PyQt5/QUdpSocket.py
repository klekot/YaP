# encoding: utf-8
# module PyQt5.QtNetwork
# from C:\Python34\lib\site-packages\PyQt5\QtNetwork.pyd
# by generator 1.136
# no doc

# imports
import PyQt5.QtCore as __PyQt5_QtCore


from .QAbstractSocket import QAbstractSocket

class QUdpSocket(QAbstractSocket):
    """ QUdpSocket(QObject parent=None) """
    def childEvent(self, *args, **kwargs): # real signature unknown
        pass

    def connectNotify(self, *args, **kwargs): # real signature unknown
        pass

    def customEvent(self, *args, **kwargs): # real signature unknown
        pass

    def disconnectNotify(self, *args, **kwargs): # real signature unknown
        pass

    def hasPendingDatagrams(self): # real signature unknown; restored from __doc__
        """ QUdpSocket.hasPendingDatagrams() -> bool """
        return False

    def isSignalConnected(self, *args, **kwargs): # real signature unknown
        pass

    def joinMulticastGroup(self, QHostAddress, QNetworkInterface=None): # real signature unknown; restored from __doc__ with multiple overloads
        """
        QUdpSocket.joinMulticastGroup(QHostAddress) -> bool
        QUdpSocket.joinMulticastGroup(QHostAddress, QNetworkInterface) -> bool
        """
        return False

    def leaveMulticastGroup(self, QHostAddress, QNetworkInterface=None): # real signature unknown; restored from __doc__ with multiple overloads
        """
        QUdpSocket.leaveMulticastGroup(QHostAddress) -> bool
        QUdpSocket.leaveMulticastGroup(QHostAddress, QNetworkInterface) -> bool
        """
        return False

    def multicastInterface(self): # real signature unknown; restored from __doc__
        """ QUdpSocket.multicastInterface() -> QNetworkInterface """
        return QNetworkInterface

    def pendingDatagramSize(self): # real signature unknown; restored from __doc__
        """ QUdpSocket.pendingDatagramSize() -> int """
        return 0

    def readData(self, *args, **kwargs): # real signature unknown
        pass

    def readDatagram(self, p_int): # real signature unknown; restored from __doc__
        """ QUdpSocket.readDatagram(int) -> (bytes, QHostAddress, int) """
        pass

    def readLineData(self, *args, **kwargs): # real signature unknown
        pass

    def receivers(self, *args, **kwargs): # real signature unknown
        pass

    def sender(self, *args, **kwargs): # real signature unknown
        pass

    def senderSignalIndex(self, *args, **kwargs): # real signature unknown
        pass

    def setErrorString(self, *args, **kwargs): # real signature unknown
        pass

    def setLocalAddress(self, *args, **kwargs): # real signature unknown
        pass

    def setLocalPort(self, *args, **kwargs): # real signature unknown
        pass

    def setMulticastInterface(self, QNetworkInterface): # real signature unknown; restored from __doc__
        """ QUdpSocket.setMulticastInterface(QNetworkInterface) """
        pass

    def setOpenMode(self, *args, **kwargs): # real signature unknown
        pass

    def setPeerAddress(self, *args, **kwargs): # real signature unknown
        pass

    def setPeerName(self, *args, **kwargs): # real signature unknown
        pass

    def setPeerPort(self, *args, **kwargs): # real signature unknown
        pass

    def setSocketError(self, *args, **kwargs): # real signature unknown
        pass

    def setSocketState(self, *args, **kwargs): # real signature unknown
        pass

    def timerEvent(self, *args, **kwargs): # real signature unknown
        pass

    def writeData(self, *args, **kwargs): # real signature unknown
        pass

    def writeDatagram(self, *__args): # real signature unknown; restored from __doc__ with multiple overloads
        """
        QUdpSocket.writeDatagram(str, QHostAddress, int) -> int
        QUdpSocket.writeDatagram(QByteArray, QHostAddress, int) -> int
        """
        return 0

    def __init__(self, QObject_parent=None): # real signature unknown; restored from __doc__
        pass


