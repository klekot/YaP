# encoding: utf-8
# module PyQt5.QtNetwork
# from C:\Python34\lib\site-packages\PyQt5\QtNetwork.pyd
# by generator 1.136
# no doc

# imports
import PyQt5.QtCore as __PyQt5_QtCore


class QNetworkCookieJar(__PyQt5_QtCore.QObject):
    """ QNetworkCookieJar(QObject parent=None) """
    def allCookies(self): # real signature unknown; restored from __doc__
        """ QNetworkCookieJar.allCookies() -> list-of-QNetworkCookie """
        pass

    def childEvent(self, *args, **kwargs): # real signature unknown
        pass

    def connectNotify(self, *args, **kwargs): # real signature unknown
        pass

    def cookiesForUrl(self, QUrl): # real signature unknown; restored from __doc__
        """ QNetworkCookieJar.cookiesForUrl(QUrl) -> list-of-QNetworkCookie """
        pass

    def customEvent(self, *args, **kwargs): # real signature unknown
        pass

    def deleteCookie(self, QNetworkCookie): # real signature unknown; restored from __doc__
        """ QNetworkCookieJar.deleteCookie(QNetworkCookie) -> bool """
        return False

    def disconnectNotify(self, *args, **kwargs): # real signature unknown
        pass

    def insertCookie(self, QNetworkCookie): # real signature unknown; restored from __doc__
        """ QNetworkCookieJar.insertCookie(QNetworkCookie) -> bool """
        return False

    def isSignalConnected(self, *args, **kwargs): # real signature unknown
        pass

    def receivers(self, *args, **kwargs): # real signature unknown
        pass

    def sender(self, *args, **kwargs): # real signature unknown
        pass

    def senderSignalIndex(self, *args, **kwargs): # real signature unknown
        pass

    def setAllCookies(self, list_of_QNetworkCookie): # real signature unknown; restored from __doc__
        """ QNetworkCookieJar.setAllCookies(list-of-QNetworkCookie) """
        pass

    def setCookiesFromUrl(self, list_of_QNetworkCookie, QUrl): # real signature unknown; restored from __doc__
        """ QNetworkCookieJar.setCookiesFromUrl(list-of-QNetworkCookie, QUrl) -> bool """
        return False

    def timerEvent(self, *args, **kwargs): # real signature unknown
        pass

    def updateCookie(self, QNetworkCookie): # real signature unknown; restored from __doc__
        """ QNetworkCookieJar.updateCookie(QNetworkCookie) -> bool """
        return False

    def validateCookie(self, QNetworkCookie, QUrl): # real signature unknown; restored from __doc__
        """ QNetworkCookieJar.validateCookie(QNetworkCookie, QUrl) -> bool """
        return False

    def __init__(self, QObject_parent=None): # real signature unknown; restored from __doc__
        pass


