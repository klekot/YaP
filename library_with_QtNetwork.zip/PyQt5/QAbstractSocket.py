# encoding: utf-8
# module PyQt5.QtNetwork
# from C:\Python34\lib\site-packages\PyQt5\QtNetwork.pyd
# by generator 1.136
# no doc

# imports
import PyQt5.QtCore as __PyQt5_QtCore


class QAbstractSocket(__PyQt5_QtCore.QIODevice):
    """ QAbstractSocket(QAbstractSocket.SocketType, QObject) """
    def abort(self): # real signature unknown; restored from __doc__
        """ QAbstractSocket.abort() """
        pass

    def atEnd(self): # real signature unknown; restored from __doc__
        """ QAbstractSocket.atEnd() -> bool """
        return False

    def bind(self, *__args): # real signature unknown; restored from __doc__ with multiple overloads
        """
        QAbstractSocket.bind(QHostAddress, int port=0, QAbstractSocket.BindMode mode=QAbstractSocket.DefaultForPlatform) -> bool
        QAbstractSocket.bind(int port=0, QAbstractSocket.BindMode mode=QAbstractSocket.DefaultForPlatform) -> bool
        """
        return False

    def bytesAvailable(self): # real signature unknown; restored from __doc__
        """ QAbstractSocket.bytesAvailable() -> int """
        return 0

    def bytesToWrite(self): # real signature unknown; restored from __doc__
        """ QAbstractSocket.bytesToWrite() -> int """
        return 0

    def canReadLine(self): # real signature unknown; restored from __doc__
        """ QAbstractSocket.canReadLine() -> bool """
        return False

    def childEvent(self, *args, **kwargs): # real signature unknown
        pass

    def close(self): # real signature unknown; restored from __doc__
        """ QAbstractSocket.close() """
        pass

    def connected(self, *args, **kwargs): # real signature unknown
        """ QAbstractSocket.connected [signal] """
        pass

    def connectNotify(self, *args, **kwargs): # real signature unknown
        pass

    def connectToHost(self, *__args): # real signature unknown; restored from __doc__ with multiple overloads
        """
        QAbstractSocket.connectToHost(str, int, QIODevice.OpenMode mode=QIODevice.ReadWrite, QAbstractSocket.NetworkLayerProtocol protocol=QAbstractSocket.AnyIPProtocol)
        QAbstractSocket.connectToHost(QHostAddress, int, QIODevice.OpenMode mode=QIODevice.ReadWrite)
        """
        pass

    def customEvent(self, *args, **kwargs): # real signature unknown
        pass

    def disconnected(self, *args, **kwargs): # real signature unknown
        """ QAbstractSocket.disconnected [signal] """
        pass

    def disconnectFromHost(self): # real signature unknown; restored from __doc__
        """ QAbstractSocket.disconnectFromHost() """
        pass

    def disconnectNotify(self, *args, **kwargs): # real signature unknown
        pass

    def error(self): # real signature unknown; restored from __doc__
        """
        QAbstractSocket.error() -> QAbstractSocket.SocketError
        QAbstractSocket.error[QAbstractSocket.SocketError] [signal]
        """
        pass

    def flush(self): # real signature unknown; restored from __doc__
        """ QAbstractSocket.flush() -> bool """
        return False

    def hostFound(self, *args, **kwargs): # real signature unknown
        """ QAbstractSocket.hostFound [signal] """
        pass

    def isSequential(self): # real signature unknown; restored from __doc__
        """ QAbstractSocket.isSequential() -> bool """
        return False

    def isSignalConnected(self, *args, **kwargs): # real signature unknown
        pass

    def isValid(self): # real signature unknown; restored from __doc__
        """ QAbstractSocket.isValid() -> bool """
        return False

    def localAddress(self): # real signature unknown; restored from __doc__
        """ QAbstractSocket.localAddress() -> QHostAddress """
        return QHostAddress

    def localPort(self): # real signature unknown; restored from __doc__
        """ QAbstractSocket.localPort() -> int """
        return 0

    def pauseMode(self): # real signature unknown; restored from __doc__
        """ QAbstractSocket.pauseMode() -> QAbstractSocket.PauseModes """
        pass

    def peerAddress(self): # real signature unknown; restored from __doc__
        """ QAbstractSocket.peerAddress() -> QHostAddress """
        return QHostAddress

    def peerName(self): # real signature unknown; restored from __doc__
        """ QAbstractSocket.peerName() -> str """
        return ""

    def peerPort(self): # real signature unknown; restored from __doc__
        """ QAbstractSocket.peerPort() -> int """
        return 0

    def proxy(self): # real signature unknown; restored from __doc__
        """ QAbstractSocket.proxy() -> QNetworkProxy """
        return QNetworkProxy

    def proxyAuthenticationRequired(self, *args, **kwargs): # real signature unknown
        """ QAbstractSocket.proxyAuthenticationRequired[QNetworkProxy, QAuthenticator] [signal] """
        pass

    def readBufferSize(self): # real signature unknown; restored from __doc__
        """ QAbstractSocket.readBufferSize() -> int """
        return 0

    def readData(self, p_int): # real signature unknown; restored from __doc__
        """ QAbstractSocket.readData(int) -> bytes """
        return b""

    def readLineData(self, p_int): # real signature unknown; restored from __doc__
        """ QAbstractSocket.readLineData(int) -> bytes """
        return b""

    def receivers(self, *args, **kwargs): # real signature unknown
        pass

    def resume(self): # real signature unknown; restored from __doc__
        """ QAbstractSocket.resume() """
        pass

    def sender(self, *args, **kwargs): # real signature unknown
        pass

    def senderSignalIndex(self, *args, **kwargs): # real signature unknown
        pass

    def setErrorString(self, *args, **kwargs): # real signature unknown
        pass

    def setLocalAddress(self, QHostAddress): # real signature unknown; restored from __doc__
        """ QAbstractSocket.setLocalAddress(QHostAddress) """
        pass

    def setLocalPort(self, p_int): # real signature unknown; restored from __doc__
        """ QAbstractSocket.setLocalPort(int) """
        pass

    def setOpenMode(self, *args, **kwargs): # real signature unknown
        pass

    def setPauseMode(self, QAbstractSocket_PauseModes): # real signature unknown; restored from __doc__
        """ QAbstractSocket.setPauseMode(QAbstractSocket.PauseModes) """
        pass

    def setPeerAddress(self, QHostAddress): # real signature unknown; restored from __doc__
        """ QAbstractSocket.setPeerAddress(QHostAddress) """
        pass

    def setPeerName(self, p_str): # real signature unknown; restored from __doc__
        """ QAbstractSocket.setPeerName(str) """
        pass

    def setPeerPort(self, p_int): # real signature unknown; restored from __doc__
        """ QAbstractSocket.setPeerPort(int) """
        pass

    def setProxy(self, QNetworkProxy): # real signature unknown; restored from __doc__
        """ QAbstractSocket.setProxy(QNetworkProxy) """
        pass

    def setReadBufferSize(self, p_int): # real signature unknown; restored from __doc__
        """ QAbstractSocket.setReadBufferSize(int) """
        pass

    def setSocketDescriptor(self, sip_voidptr, QAbstractSocket_SocketState_state=None, QIODevice_OpenMode_mode=None): # real signature unknown; restored from __doc__
        """ QAbstractSocket.setSocketDescriptor(sip.voidptr, QAbstractSocket.SocketState state=QAbstractSocket.ConnectedState, QIODevice.OpenMode mode=QIODevice.ReadWrite) -> bool """
        return False

    def setSocketError(self, QAbstractSocket_SocketError): # real signature unknown; restored from __doc__
        """ QAbstractSocket.setSocketError(QAbstractSocket.SocketError) """
        pass

    def setSocketOption(self, QAbstractSocket_SocketOption, QVariant): # real signature unknown; restored from __doc__
        """ QAbstractSocket.setSocketOption(QAbstractSocket.SocketOption, QVariant) """
        pass

    def setSocketState(self, QAbstractSocket_SocketState): # real signature unknown; restored from __doc__
        """ QAbstractSocket.setSocketState(QAbstractSocket.SocketState) """
        pass

    def socketDescriptor(self): # real signature unknown; restored from __doc__
        """ QAbstractSocket.socketDescriptor() -> sip.voidptr """
        pass

    def socketOption(self, QAbstractSocket_SocketOption): # real signature unknown; restored from __doc__
        """ QAbstractSocket.socketOption(QAbstractSocket.SocketOption) -> QVariant """
        pass

    def socketType(self): # real signature unknown; restored from __doc__
        """ QAbstractSocket.socketType() -> QAbstractSocket.SocketType """
        pass

    def state(self): # real signature unknown; restored from __doc__
        """ QAbstractSocket.state() -> QAbstractSocket.SocketState """
        pass

    def stateChanged(self, *args, **kwargs): # real signature unknown
        """ QAbstractSocket.stateChanged[QAbstractSocket.SocketState] [signal] """
        pass

    def timerEvent(self, *args, **kwargs): # real signature unknown
        pass

    def waitForBytesWritten(self, int_msecs=30000): # real signature unknown; restored from __doc__
        """ QAbstractSocket.waitForBytesWritten(int msecs=30000) -> bool """
        return False

    def waitForConnected(self, int_msecs=30000): # real signature unknown; restored from __doc__
        """ QAbstractSocket.waitForConnected(int msecs=30000) -> bool """
        return False

    def waitForDisconnected(self, int_msecs=30000): # real signature unknown; restored from __doc__
        """ QAbstractSocket.waitForDisconnected(int msecs=30000) -> bool """
        return False

    def waitForReadyRead(self, int_msecs=30000): # real signature unknown; restored from __doc__
        """ QAbstractSocket.waitForReadyRead(int msecs=30000) -> bool """
        return False

    def writeData(self, p_str): # real signature unknown; restored from __doc__
        """ QAbstractSocket.writeData(str) -> int """
        return 0

    def __init__(self, QAbstractSocket_SocketType, QObject): # real signature unknown; restored from __doc__
        pass

    AddressInUseError = 8
    AnyIPProtocol = 2
    BoundState = 4
    ClosingState = 6
    ConnectedState = 3
    ConnectingState = 2
    ConnectionRefusedError = 0
    DatagramTooLargeError = 6
    DefaultForPlatform = 0
    DontShareAddress = 2
    HostLookupState = 1
    HostNotFoundError = 2
    IPv4Protocol = 0
    IPv6Protocol = 1
    KeepAliveOption = 1
    ListeningState = 5
    LowDelayOption = 0
    MulticastLoopbackOption = 3
    MulticastTtlOption = 2
    NetworkError = 7
    OperationError = 19
    PauseNever = 0
    PauseOnSslErrors = 1
    ProxyAuthenticationRequiredError = 12
    ProxyConnectionClosedError = 15
    ProxyConnectionRefusedError = 14
    ProxyConnectionTimeoutError = 16
    ProxyNotFoundError = 17
    ProxyProtocolError = 18
    ReceiveBufferSizeSocketOption = 6
    RemoteHostClosedError = 1
    ReuseAddressHint = 4
    SendBufferSizeSocketOption = 5
    ShareAddress = 1
    SocketAccessError = 3
    SocketAddressNotAvailableError = 9
    SocketResourceError = 4
    SocketTimeoutError = 5
    SslHandshakeFailedError = 13
    SslInternalError = 20
    SslInvalidUserDataError = 21
    TcpSocket = 0
    TemporaryError = 22
    TypeOfServiceOption = 4
    UdpSocket = 1
    UnconnectedState = 0
    UnfinishedSocketOperationError = 11
    UnknownNetworkLayerProtocol = -1
    UnknownSocketError = -1
    UnknownSocketType = -1
    UnsupportedSocketOperationError = 10


