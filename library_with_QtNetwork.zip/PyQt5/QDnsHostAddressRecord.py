# encoding: utf-8
# module PyQt5.QtNetwork
# from C:\Python34\lib\site-packages\PyQt5\QtNetwork.pyd
# by generator 1.136
# no doc

# imports
import PyQt5.QtCore as __PyQt5_QtCore


class QDnsHostAddressRecord(): # skipped bases: <class 'sip.simplewrapper'>
    """
    QDnsHostAddressRecord()
    QDnsHostAddressRecord(QDnsHostAddressRecord)
    """
    def name(self): # real signature unknown; restored from __doc__
        """ QDnsHostAddressRecord.name() -> str """
        return ""

    def swap(self, QDnsHostAddressRecord): # real signature unknown; restored from __doc__
        """ QDnsHostAddressRecord.swap(QDnsHostAddressRecord) """
        pass

    def timeToLive(self): # real signature unknown; restored from __doc__
        """ QDnsHostAddressRecord.timeToLive() -> int """
        return 0

    def value(self): # real signature unknown; restored from __doc__
        """ QDnsHostAddressRecord.value() -> QHostAddress """
        return QHostAddress

    def __init__(self, QDnsHostAddressRecord=None): # real signature unknown; restored from __doc__ with multiple overloads
        pass

    __weakref__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """list of weak references to the object (if defined)"""



