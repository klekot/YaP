# encoding: utf-8
# module PyQt5.QtNetwork
# from C:\Python34\lib\site-packages\PyQt5\QtNetwork.pyd
# by generator 1.136
# no doc

# imports
import PyQt5.QtCore as __PyQt5_QtCore


class QHostInfo(): # skipped bases: <class 'sip.simplewrapper'>
    """
    QHostInfo(int id=-1)
    QHostInfo(QHostInfo)
    """
    def abortHostLookup(self, p_int): # real signature unknown; restored from __doc__
        """ QHostInfo.abortHostLookup(int) """
        pass

    def addresses(self): # real signature unknown; restored from __doc__
        """ QHostInfo.addresses() -> list-of-QHostAddress """
        pass

    def error(self): # real signature unknown; restored from __doc__
        """ QHostInfo.error() -> QHostInfo.HostInfoError """
        pass

    def errorString(self): # real signature unknown; restored from __doc__
        """ QHostInfo.errorString() -> str """
        return ""

    def fromName(self, p_str): # real signature unknown; restored from __doc__
        """ QHostInfo.fromName(str) -> QHostInfo """
        return QHostInfo

    def hostName(self): # real signature unknown; restored from __doc__
        """ QHostInfo.hostName() -> str """
        return ""

    def localDomainName(self): # real signature unknown; restored from __doc__
        """ QHostInfo.localDomainName() -> str """
        return ""

    def localHostName(self): # real signature unknown; restored from __doc__
        """ QHostInfo.localHostName() -> str """
        return ""

    def lookupHost(self, p_str, callable_or_signal): # real signature unknown; restored from __doc__
        """ QHostInfo.lookupHost(str, callable-or-signal) -> int """
        return 0

    def lookupId(self): # real signature unknown; restored from __doc__
        """ QHostInfo.lookupId() -> int """
        return 0

    def setAddresses(self, list_of_QHostAddress): # real signature unknown; restored from __doc__
        """ QHostInfo.setAddresses(list-of-QHostAddress) """
        pass

    def setError(self, QHostInfo_HostInfoError): # real signature unknown; restored from __doc__
        """ QHostInfo.setError(QHostInfo.HostInfoError) """
        pass

    def setErrorString(self, p_str): # real signature unknown; restored from __doc__
        """ QHostInfo.setErrorString(str) """
        pass

    def setHostName(self, p_str): # real signature unknown; restored from __doc__
        """ QHostInfo.setHostName(str) """
        pass

    def setLookupId(self, p_int): # real signature unknown; restored from __doc__
        """ QHostInfo.setLookupId(int) """
        pass

    def __init__(self, *__args): # real signature unknown; restored from __doc__ with multiple overloads
        pass

    __weakref__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """list of weak references to the object (if defined)"""


    HostNotFound = 1
    NoError = 0
    UnknownError = 2


