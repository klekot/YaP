# encoding: utf-8
# module PyQt5.QtNetwork
# from C:\Python34\lib\site-packages\PyQt5\QtNetwork.pyd
# by generator 1.136
# no doc

# imports
import PyQt5.QtCore as __PyQt5_QtCore


class QNetworkProxyFactory(): # skipped bases: <class 'sip.wrapper'>
    """
    QNetworkProxyFactory()
    QNetworkProxyFactory(QNetworkProxyFactory)
    """
    def proxyForQuery(self, QNetworkProxyQuery): # real signature unknown; restored from __doc__
        """ QNetworkProxyFactory.proxyForQuery(QNetworkProxyQuery) -> list-of-QNetworkProxy """
        pass

    def queryProxy(self, QNetworkProxyQuery_query=None, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
        """ QNetworkProxyFactory.queryProxy(QNetworkProxyQuery query=QNetworkProxyQuery()) -> list-of-QNetworkProxy """
        pass

    def setApplicationProxyFactory(self, QNetworkProxyFactory): # real signature unknown; restored from __doc__
        """ QNetworkProxyFactory.setApplicationProxyFactory(QNetworkProxyFactory) """
        pass

    def setUseSystemConfiguration(self, bool): # real signature unknown; restored from __doc__
        """ QNetworkProxyFactory.setUseSystemConfiguration(bool) """
        pass

    def systemProxyForQuery(self, QNetworkProxyQuery_query=None, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
        """ QNetworkProxyFactory.systemProxyForQuery(QNetworkProxyQuery query=QNetworkProxyQuery()) -> list-of-QNetworkProxy """
        pass

    def __init__(self, QNetworkProxyFactory=None): # real signature unknown; restored from __doc__ with multiple overloads
        pass

    __weakref__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """list of weak references to the object (if defined)"""



