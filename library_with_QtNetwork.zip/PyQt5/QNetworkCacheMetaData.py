# encoding: utf-8
# module PyQt5.QtNetwork
# from C:\Python34\lib\site-packages\PyQt5\QtNetwork.pyd
# by generator 1.136
# no doc

# imports
import PyQt5.QtCore as __PyQt5_QtCore


class QNetworkCacheMetaData(): # skipped bases: <class 'sip.simplewrapper'>
    """
    QNetworkCacheMetaData()
    QNetworkCacheMetaData(QNetworkCacheMetaData)
    """
    def attributes(self): # real signature unknown; restored from __doc__
        """ QNetworkCacheMetaData.attributes() -> dict-of-QNetworkRequest.Attribute-object """
        pass

    def expirationDate(self): # real signature unknown; restored from __doc__
        """ QNetworkCacheMetaData.expirationDate() -> QDateTime """
        pass

    def isValid(self): # real signature unknown; restored from __doc__
        """ QNetworkCacheMetaData.isValid() -> bool """
        return False

    def lastModified(self): # real signature unknown; restored from __doc__
        """ QNetworkCacheMetaData.lastModified() -> QDateTime """
        pass

    def rawHeaders(self): # real signature unknown; restored from __doc__
        """ QNetworkCacheMetaData.rawHeaders() -> list-of-tuple-of-QByteArray-QByteArray """
        pass

    def saveToDisk(self): # real signature unknown; restored from __doc__
        """ QNetworkCacheMetaData.saveToDisk() -> bool """
        return False

    def setAttributes(self, dict_of_QNetworkRequest_Attribute_object): # real signature unknown; restored from __doc__
        """ QNetworkCacheMetaData.setAttributes(dict-of-QNetworkRequest.Attribute-object) """
        pass

    def setExpirationDate(self, QDateTime): # real signature unknown; restored from __doc__
        """ QNetworkCacheMetaData.setExpirationDate(QDateTime) """
        pass

    def setLastModified(self, QDateTime): # real signature unknown; restored from __doc__
        """ QNetworkCacheMetaData.setLastModified(QDateTime) """
        pass

    def setRawHeaders(self, list_of_tuple_of_QByteArray_QByteArray): # real signature unknown; restored from __doc__
        """ QNetworkCacheMetaData.setRawHeaders(list-of-tuple-of-QByteArray-QByteArray) """
        pass

    def setSaveToDisk(self, bool): # real signature unknown; restored from __doc__
        """ QNetworkCacheMetaData.setSaveToDisk(bool) """
        pass

    def setUrl(self, QUrl): # real signature unknown; restored from __doc__
        """ QNetworkCacheMetaData.setUrl(QUrl) """
        pass

    def swap(self, QNetworkCacheMetaData): # real signature unknown; restored from __doc__
        """ QNetworkCacheMetaData.swap(QNetworkCacheMetaData) """
        pass

    def url(self): # real signature unknown; restored from __doc__
        """ QNetworkCacheMetaData.url() -> QUrl """
        pass

    def __eq__(self, *args, **kwargs): # real signature unknown
        """ Return self==value. """
        pass

    def __ge__(self, *args, **kwargs): # real signature unknown
        """ Return self>=value. """
        pass

    def __gt__(self, *args, **kwargs): # real signature unknown
        """ Return self>value. """
        pass

    def __init__(self, QNetworkCacheMetaData=None): # real signature unknown; restored from __doc__ with multiple overloads
        pass

    def __le__(self, *args, **kwargs): # real signature unknown
        """ Return self<=value. """
        pass

    def __lt__(self, *args, **kwargs): # real signature unknown
        """ Return self<value. """
        pass

    def __ne__(self, *args, **kwargs): # real signature unknown
        """ Return self!=value. """
        pass

    __weakref__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """list of weak references to the object (if defined)"""


    __hash__ = None


