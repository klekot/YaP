# encoding: utf-8
# module PyQt5.QtNetwork
# from C:\Python34\lib\site-packages\PyQt5\QtNetwork.pyd
# by generator 1.136
# no doc

# imports
import PyQt5.QtCore as __PyQt5_QtCore


class QSsl(): # skipped bases: <class 'sip.wrapper'>
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """list of weak references to the object (if defined)"""


    AnyProtocol = 5
    Der = 1
    DnsEntry = 1
    Dsa = 2
    EmailEntry = 0
    Opaque = 0
    Pem = 0
    PrivateKey = 0
    PublicKey = 1
    Rsa = 1
    SecureProtocols = 7
    SslOptionDisableCompression = 4
    SslOptionDisableEmptyFragments = 1
    SslOptionDisableLegacyRenegotiation = 16
    SslOptionDisableServerNameIndication = 8
    SslOptionDisableSessionPersistence = 64
    SslOptionDisableSessionSharing = 32
    SslOptionDisableSessionTickets = 2
    SslV2 = 1
    SslV3 = 0
    TlsV1SslV3 = 6
    TlsV1_0 = 2
    TlsV1_1 = 3
    TlsV1_2 = 4
    UnknownProtocol = -1


