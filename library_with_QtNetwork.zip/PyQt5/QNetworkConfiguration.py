# encoding: utf-8
# module PyQt5.QtNetwork
# from C:\Python34\lib\site-packages\PyQt5\QtNetwork.pyd
# by generator 1.136
# no doc

# imports
import PyQt5.QtCore as __PyQt5_QtCore


class QNetworkConfiguration(): # skipped bases: <class 'sip.simplewrapper'>
    """
    QNetworkConfiguration()
    QNetworkConfiguration(QNetworkConfiguration)
    """
    def bearerType(self): # real signature unknown; restored from __doc__
        """ QNetworkConfiguration.bearerType() -> QNetworkConfiguration.BearerType """
        pass

    def bearerTypeFamily(self): # real signature unknown; restored from __doc__
        """ QNetworkConfiguration.bearerTypeFamily() -> QNetworkConfiguration.BearerType """
        pass

    def bearerTypeName(self): # real signature unknown; restored from __doc__
        """ QNetworkConfiguration.bearerTypeName() -> str """
        return ""

    def children(self): # real signature unknown; restored from __doc__
        """ QNetworkConfiguration.children() -> list-of-QNetworkConfiguration """
        pass

    def identifier(self): # real signature unknown; restored from __doc__
        """ QNetworkConfiguration.identifier() -> str """
        return ""

    def isRoamingAvailable(self): # real signature unknown; restored from __doc__
        """ QNetworkConfiguration.isRoamingAvailable() -> bool """
        return False

    def isValid(self): # real signature unknown; restored from __doc__
        """ QNetworkConfiguration.isValid() -> bool """
        return False

    def name(self): # real signature unknown; restored from __doc__
        """ QNetworkConfiguration.name() -> str """
        return ""

    def purpose(self): # real signature unknown; restored from __doc__
        """ QNetworkConfiguration.purpose() -> QNetworkConfiguration.Purpose """
        pass

    def state(self): # real signature unknown; restored from __doc__
        """ QNetworkConfiguration.state() -> QNetworkConfiguration.StateFlags """
        pass

    def swap(self, QNetworkConfiguration): # real signature unknown; restored from __doc__
        """ QNetworkConfiguration.swap(QNetworkConfiguration) """
        pass

    def type(self): # real signature unknown; restored from __doc__
        """ QNetworkConfiguration.type() -> QNetworkConfiguration.Type """
        pass

    def __eq__(self, *args, **kwargs): # real signature unknown
        """ Return self==value. """
        pass

    def __ge__(self, *args, **kwargs): # real signature unknown
        """ Return self>=value. """
        pass

    def __gt__(self, *args, **kwargs): # real signature unknown
        """ Return self>value. """
        pass

    def __init__(self, QNetworkConfiguration=None): # real signature unknown; restored from __doc__ with multiple overloads
        pass

    def __le__(self, *args, **kwargs): # real signature unknown
        """ Return self<=value. """
        pass

    def __lt__(self, *args, **kwargs): # real signature unknown
        """ Return self<value. """
        pass

    def __ne__(self, *args, **kwargs): # real signature unknown
        """ Return self!=value. """
        pass

    __weakref__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """list of weak references to the object (if defined)"""


    Active = 14
    Bearer2G = 3
    Bearer3G = 11
    Bearer4G = 12
    BearerBluetooth = 7
    BearerCDMA2000 = 4
    BearerEthernet = 1
    BearerEVDO = 9
    BearerHSPA = 6
    BearerLTE = 10
    BearerUnknown = 0
    BearerWCDMA = 5
    BearerWiMAX = 8
    BearerWLAN = 2
    Defined = 2
    Discovered = 6
    InternetAccessPoint = 0
    Invalid = 3
    PrivatePurpose = 2
    PublicPurpose = 1
    ServiceNetwork = 1
    ServiceSpecificPurpose = 3
    Undefined = 1
    UnknownPurpose = 0
    UserChoice = 2
    __hash__ = None


