# encoding: utf-8
# module PyQt5.QtNetwork
# from C:\Python34\lib\site-packages\PyQt5\QtNetwork.pyd
# by generator 1.136
# no doc

# imports
import PyQt5.QtCore as __PyQt5_QtCore


class QTcpServer(__PyQt5_QtCore.QObject):
    """ QTcpServer(QObject parent=None) """
    def acceptError(self, *args, **kwargs): # real signature unknown
        """ QTcpServer.acceptError[QAbstractSocket.SocketError] [signal] """
        pass

    def addPendingConnection(self, QTcpSocket): # real signature unknown; restored from __doc__
        """ QTcpServer.addPendingConnection(QTcpSocket) """
        pass

    def childEvent(self, *args, **kwargs): # real signature unknown
        pass

    def close(self): # real signature unknown; restored from __doc__
        """ QTcpServer.close() """
        pass

    def connectNotify(self, *args, **kwargs): # real signature unknown
        pass

    def customEvent(self, *args, **kwargs): # real signature unknown
        pass

    def disconnectNotify(self, *args, **kwargs): # real signature unknown
        pass

    def errorString(self): # real signature unknown; restored from __doc__
        """ QTcpServer.errorString() -> str """
        return ""

    def hasPendingConnections(self): # real signature unknown; restored from __doc__
        """ QTcpServer.hasPendingConnections() -> bool """
        return False

    def incomingConnection(self, sip_voidptr): # real signature unknown; restored from __doc__
        """ QTcpServer.incomingConnection(sip.voidptr) """
        pass

    def isListening(self): # real signature unknown; restored from __doc__
        """ QTcpServer.isListening() -> bool """
        return False

    def isSignalConnected(self, *args, **kwargs): # real signature unknown
        pass

    def listen(self, QHostAddress_address=None, int_port=0): # real signature unknown; restored from __doc__
        """ QTcpServer.listen(QHostAddress address=QHostAddress.Any, int port=0) -> bool """
        return False

    def maxPendingConnections(self): # real signature unknown; restored from __doc__
        """ QTcpServer.maxPendingConnections() -> int """
        return 0

    def newConnection(self, *args, **kwargs): # real signature unknown
        """ QTcpServer.newConnection [signal] """
        pass

    def nextPendingConnection(self): # real signature unknown; restored from __doc__
        """ QTcpServer.nextPendingConnection() -> QTcpSocket """
        return QTcpSocket

    def pauseAccepting(self): # real signature unknown; restored from __doc__
        """ QTcpServer.pauseAccepting() """
        pass

    def proxy(self): # real signature unknown; restored from __doc__
        """ QTcpServer.proxy() -> QNetworkProxy """
        return QNetworkProxy

    def receivers(self, *args, **kwargs): # real signature unknown
        pass

    def resumeAccepting(self): # real signature unknown; restored from __doc__
        """ QTcpServer.resumeAccepting() """
        pass

    def sender(self, *args, **kwargs): # real signature unknown
        pass

    def senderSignalIndex(self, *args, **kwargs): # real signature unknown
        pass

    def serverAddress(self): # real signature unknown; restored from __doc__
        """ QTcpServer.serverAddress() -> QHostAddress """
        return QHostAddress

    def serverError(self): # real signature unknown; restored from __doc__
        """ QTcpServer.serverError() -> QAbstractSocket.SocketError """
        pass

    def serverPort(self): # real signature unknown; restored from __doc__
        """ QTcpServer.serverPort() -> int """
        return 0

    def setMaxPendingConnections(self, p_int): # real signature unknown; restored from __doc__
        """ QTcpServer.setMaxPendingConnections(int) """
        pass

    def setProxy(self, QNetworkProxy): # real signature unknown; restored from __doc__
        """ QTcpServer.setProxy(QNetworkProxy) """
        pass

    def setSocketDescriptor(self, sip_voidptr): # real signature unknown; restored from __doc__
        """ QTcpServer.setSocketDescriptor(sip.voidptr) -> bool """
        return False

    def socketDescriptor(self): # real signature unknown; restored from __doc__
        """ QTcpServer.socketDescriptor() -> sip.voidptr """
        pass

    def timerEvent(self, *args, **kwargs): # real signature unknown
        pass

    def waitForNewConnection(self, int_msecs=0): # real signature unknown; restored from __doc__
        """ QTcpServer.waitForNewConnection(int msecs=0) -> (bool, bool) """
        pass

    def __init__(self, QObject_parent=None): # real signature unknown; restored from __doc__
        pass


