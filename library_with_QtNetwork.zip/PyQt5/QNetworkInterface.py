# encoding: utf-8
# module PyQt5.QtNetwork
# from C:\Python34\lib\site-packages\PyQt5\QtNetwork.pyd
# by generator 1.136
# no doc

# imports
import PyQt5.QtCore as __PyQt5_QtCore


class QNetworkInterface(): # skipped bases: <class 'sip.simplewrapper'>
    """
    QNetworkInterface()
    QNetworkInterface(QNetworkInterface)
    """
    def addressEntries(self): # real signature unknown; restored from __doc__
        """ QNetworkInterface.addressEntries() -> list-of-QNetworkAddressEntry """
        pass

    def allAddresses(self): # real signature unknown; restored from __doc__
        """ QNetworkInterface.allAddresses() -> list-of-QHostAddress """
        pass

    def allInterfaces(self): # real signature unknown; restored from __doc__
        """ QNetworkInterface.allInterfaces() -> list-of-QNetworkInterface """
        pass

    def flags(self): # real signature unknown; restored from __doc__
        """ QNetworkInterface.flags() -> QNetworkInterface.InterfaceFlags """
        pass

    def hardwareAddress(self): # real signature unknown; restored from __doc__
        """ QNetworkInterface.hardwareAddress() -> str """
        return ""

    def humanReadableName(self): # real signature unknown; restored from __doc__
        """ QNetworkInterface.humanReadableName() -> str """
        return ""

    def index(self): # real signature unknown; restored from __doc__
        """ QNetworkInterface.index() -> int """
        return 0

    def interfaceFromIndex(self, p_int): # real signature unknown; restored from __doc__
        """ QNetworkInterface.interfaceFromIndex(int) -> QNetworkInterface """
        return QNetworkInterface

    def interfaceFromName(self, p_str): # real signature unknown; restored from __doc__
        """ QNetworkInterface.interfaceFromName(str) -> QNetworkInterface """
        return QNetworkInterface

    def isValid(self): # real signature unknown; restored from __doc__
        """ QNetworkInterface.isValid() -> bool """
        return False

    def name(self): # real signature unknown; restored from __doc__
        """ QNetworkInterface.name() -> str """
        return ""

    def swap(self, QNetworkInterface): # real signature unknown; restored from __doc__
        """ QNetworkInterface.swap(QNetworkInterface) """
        pass

    def __init__(self, QNetworkInterface=None): # real signature unknown; restored from __doc__ with multiple overloads
        pass

    __weakref__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """list of weak references to the object (if defined)"""


    CanBroadcast = 4
    CanMulticast = 32
    IsLoopBack = 8
    IsPointToPoint = 16
    IsRunning = 2
    IsUp = 1


