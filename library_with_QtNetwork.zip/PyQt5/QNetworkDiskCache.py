# encoding: utf-8
# module PyQt5.QtNetwork
# from C:\Python34\lib\site-packages\PyQt5\QtNetwork.pyd
# by generator 1.136
# no doc

# imports
import PyQt5.QtCore as __PyQt5_QtCore


from .QAbstractNetworkCache import QAbstractNetworkCache

class QNetworkDiskCache(QAbstractNetworkCache):
    """ QNetworkDiskCache(QObject parent=None) """
    def cacheDirectory(self): # real signature unknown; restored from __doc__
        """ QNetworkDiskCache.cacheDirectory() -> str """
        return ""

    def cacheSize(self): # real signature unknown; restored from __doc__
        """ QNetworkDiskCache.cacheSize() -> int """
        return 0

    def childEvent(self, *args, **kwargs): # real signature unknown
        pass

    def clear(self): # real signature unknown; restored from __doc__
        """ QNetworkDiskCache.clear() """
        pass

    def connectNotify(self, *args, **kwargs): # real signature unknown
        pass

    def customEvent(self, *args, **kwargs): # real signature unknown
        pass

    def data(self, QUrl): # real signature unknown; restored from __doc__
        """ QNetworkDiskCache.data(QUrl) -> QIODevice """
        pass

    def disconnectNotify(self, *args, **kwargs): # real signature unknown
        pass

    def expire(self): # real signature unknown; restored from __doc__
        """ QNetworkDiskCache.expire() -> int """
        return 0

    def fileMetaData(self, p_str): # real signature unknown; restored from __doc__
        """ QNetworkDiskCache.fileMetaData(str) -> QNetworkCacheMetaData """
        return QNetworkCacheMetaData

    def insert(self, QIODevice): # real signature unknown; restored from __doc__
        """ QNetworkDiskCache.insert(QIODevice) """
        pass

    def isSignalConnected(self, *args, **kwargs): # real signature unknown
        pass

    def maximumCacheSize(self): # real signature unknown; restored from __doc__
        """ QNetworkDiskCache.maximumCacheSize() -> int """
        return 0

    def metaData(self, QUrl): # real signature unknown; restored from __doc__
        """ QNetworkDiskCache.metaData(QUrl) -> QNetworkCacheMetaData """
        return QNetworkCacheMetaData

    def prepare(self, QNetworkCacheMetaData): # real signature unknown; restored from __doc__
        """ QNetworkDiskCache.prepare(QNetworkCacheMetaData) -> QIODevice """
        pass

    def receivers(self, *args, **kwargs): # real signature unknown
        pass

    def remove(self, QUrl): # real signature unknown; restored from __doc__
        """ QNetworkDiskCache.remove(QUrl) -> bool """
        return False

    def sender(self, *args, **kwargs): # real signature unknown
        pass

    def senderSignalIndex(self, *args, **kwargs): # real signature unknown
        pass

    def setCacheDirectory(self, p_str): # real signature unknown; restored from __doc__
        """ QNetworkDiskCache.setCacheDirectory(str) """
        pass

    def setMaximumCacheSize(self, p_int): # real signature unknown; restored from __doc__
        """ QNetworkDiskCache.setMaximumCacheSize(int) """
        pass

    def timerEvent(self, *args, **kwargs): # real signature unknown
        pass

    def updateMetaData(self, QNetworkCacheMetaData): # real signature unknown; restored from __doc__
        """ QNetworkDiskCache.updateMetaData(QNetworkCacheMetaData) """
        pass

    def __init__(self, QObject_parent=None): # real signature unknown; restored from __doc__
        pass


