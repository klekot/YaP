# encoding: utf-8
# module PyQt5.QtNetwork
# from C:\Python34\lib\site-packages\PyQt5\QtNetwork.pyd
# by generator 1.136
# no doc

# imports
import PyQt5.QtCore as __PyQt5_QtCore


class QNetworkSession(__PyQt5_QtCore.QObject):
    """ QNetworkSession(QNetworkConfiguration, QObject parent=None) """
    def accept(self): # real signature unknown; restored from __doc__
        """ QNetworkSession.accept() """
        pass

    def activeTime(self): # real signature unknown; restored from __doc__
        """ QNetworkSession.activeTime() -> int """
        return 0

    def bytesReceived(self): # real signature unknown; restored from __doc__
        """ QNetworkSession.bytesReceived() -> int """
        return 0

    def bytesWritten(self): # real signature unknown; restored from __doc__
        """ QNetworkSession.bytesWritten() -> int """
        return 0

    def childEvent(self, *args, **kwargs): # real signature unknown
        pass

    def close(self): # real signature unknown; restored from __doc__
        """ QNetworkSession.close() """
        pass

    def closed(self, *args, **kwargs): # real signature unknown
        """ QNetworkSession.closed [signal] """
        pass

    def configuration(self): # real signature unknown; restored from __doc__
        """ QNetworkSession.configuration() -> QNetworkConfiguration """
        return QNetworkConfiguration

    def connectNotify(self, QMetaMethod): # real signature unknown; restored from __doc__
        """ QNetworkSession.connectNotify(QMetaMethod) """
        pass

    def customEvent(self, *args, **kwargs): # real signature unknown
        pass

    def disconnectNotify(self, QMetaMethod): # real signature unknown; restored from __doc__
        """ QNetworkSession.disconnectNotify(QMetaMethod) """
        pass

    def error(self): # real signature unknown; restored from __doc__
        """
        QNetworkSession.error() -> QNetworkSession.SessionError
        QNetworkSession.error[QNetworkSession.SessionError] [signal]
        """
        pass

    def errorString(self): # real signature unknown; restored from __doc__
        """ QNetworkSession.errorString() -> str """
        return ""

    def ignore(self): # real signature unknown; restored from __doc__
        """ QNetworkSession.ignore() """
        pass

    def interface(self): # real signature unknown; restored from __doc__
        """ QNetworkSession.interface() -> QNetworkInterface """
        return QNetworkInterface

    def isOpen(self): # real signature unknown; restored from __doc__
        """ QNetworkSession.isOpen() -> bool """
        return False

    def isSignalConnected(self, *args, **kwargs): # real signature unknown
        pass

    def migrate(self): # real signature unknown; restored from __doc__
        """ QNetworkSession.migrate() """
        pass

    def newConfigurationActivated(self, *args, **kwargs): # real signature unknown
        """ QNetworkSession.newConfigurationActivated [signal] """
        pass

    def open(self): # real signature unknown; restored from __doc__
        """ QNetworkSession.open() """
        pass

    def opened(self, *args, **kwargs): # real signature unknown
        """ QNetworkSession.opened [signal] """
        pass

    def preferredConfigurationChanged(self, *args, **kwargs): # real signature unknown
        """ QNetworkSession.preferredConfigurationChanged[QNetworkConfiguration, bool] [signal] """
        pass

    def receivers(self, *args, **kwargs): # real signature unknown
        pass

    def reject(self): # real signature unknown; restored from __doc__
        """ QNetworkSession.reject() """
        pass

    def sender(self, *args, **kwargs): # real signature unknown
        pass

    def senderSignalIndex(self, *args, **kwargs): # real signature unknown
        pass

    def sessionProperty(self, p_str): # real signature unknown; restored from __doc__
        """ QNetworkSession.sessionProperty(str) -> QVariant """
        pass

    def setSessionProperty(self, p_str, QVariant): # real signature unknown; restored from __doc__
        """ QNetworkSession.setSessionProperty(str, QVariant) """
        pass

    def state(self): # real signature unknown; restored from __doc__
        """ QNetworkSession.state() -> QNetworkSession.State """
        pass

    def stateChanged(self, *args, **kwargs): # real signature unknown
        """ QNetworkSession.stateChanged[QNetworkSession.State] [signal] """
        pass

    def stop(self): # real signature unknown; restored from __doc__
        """ QNetworkSession.stop() """
        pass

    def timerEvent(self, *args, **kwargs): # real signature unknown
        pass

    def usagePolicies(self): # real signature unknown; restored from __doc__
        """ QNetworkSession.usagePolicies() -> QNetworkSession.UsagePolicies """
        pass

    def usagePoliciesChanged(self, *args, **kwargs): # real signature unknown
        """ QNetworkSession.usagePoliciesChanged[QNetworkSession.UsagePolicies] [signal] """
        pass

    def waitForOpened(self, int_msecs=30000): # real signature unknown; restored from __doc__
        """ QNetworkSession.waitForOpened(int msecs=30000) -> bool """
        return False

    def __init__(self, QNetworkConfiguration, QObject_parent=None): # real signature unknown; restored from __doc__
        pass

    Closing = 4
    Connected = 3
    Connecting = 2
    Disconnected = 5
    Invalid = 0
    InvalidConfigurationError = 4
    NoBackgroundTrafficPolicy = 1
    NoPolicy = 0
    NotAvailable = 1
    OperationNotSupportedError = 3
    Roaming = 6
    RoamingError = 2
    SessionAbortedError = 1
    UnknownSessionError = 0


