# encoding: utf-8
# module PyQt5.QtNetwork
# from C:\Python34\lib\site-packages\PyQt5\QtNetwork.pyd
# by generator 1.136
# no doc

# imports
import PyQt5.QtCore as __PyQt5_QtCore


class QDnsLookup(__PyQt5_QtCore.QObject):
    """
    QDnsLookup(QObject parent=None)
    QDnsLookup(QDnsLookup.Type, str, QObject parent=None)
    """
    def abort(self): # real signature unknown; restored from __doc__
        """ QDnsLookup.abort() """
        pass

    def canonicalNameRecords(self): # real signature unknown; restored from __doc__
        """ QDnsLookup.canonicalNameRecords() -> list-of-QDnsDomainNameRecord """
        pass

    def childEvent(self, *args, **kwargs): # real signature unknown
        pass

    def connectNotify(self, *args, **kwargs): # real signature unknown
        pass

    def customEvent(self, *args, **kwargs): # real signature unknown
        pass

    def disconnectNotify(self, *args, **kwargs): # real signature unknown
        pass

    def error(self): # real signature unknown; restored from __doc__
        """ QDnsLookup.error() -> QDnsLookup.Error """
        pass

    def errorString(self): # real signature unknown; restored from __doc__
        """ QDnsLookup.errorString() -> str """
        return ""

    def finished(self, *args, **kwargs): # real signature unknown
        """ QDnsLookup.finished [signal] """
        pass

    def hostAddressRecords(self): # real signature unknown; restored from __doc__
        """ QDnsLookup.hostAddressRecords() -> list-of-QDnsHostAddressRecord """
        pass

    def isFinished(self): # real signature unknown; restored from __doc__
        """ QDnsLookup.isFinished() -> bool """
        return False

    def isSignalConnected(self, *args, **kwargs): # real signature unknown
        pass

    def lookup(self): # real signature unknown; restored from __doc__
        """ QDnsLookup.lookup() """
        pass

    def mailExchangeRecords(self): # real signature unknown; restored from __doc__
        """ QDnsLookup.mailExchangeRecords() -> list-of-QDnsMailExchangeRecord """
        pass

    def name(self): # real signature unknown; restored from __doc__
        """ QDnsLookup.name() -> str """
        return ""

    def nameChanged(self, *args, **kwargs): # real signature unknown
        """ QDnsLookup.nameChanged[str] [signal] """
        pass

    def nameserver(self): # real signature unknown; restored from __doc__
        """ QDnsLookup.nameserver() -> QHostAddress """
        return QHostAddress

    def nameserverChanged(self, *args, **kwargs): # real signature unknown
        """ QDnsLookup.nameserverChanged[QHostAddress] [signal] """
        pass

    def nameServerRecords(self): # real signature unknown; restored from __doc__
        """ QDnsLookup.nameServerRecords() -> list-of-QDnsDomainNameRecord """
        pass

    def pointerRecords(self): # real signature unknown; restored from __doc__
        """ QDnsLookup.pointerRecords() -> list-of-QDnsDomainNameRecord """
        pass

    def receivers(self, *args, **kwargs): # real signature unknown
        pass

    def sender(self, *args, **kwargs): # real signature unknown
        pass

    def senderSignalIndex(self, *args, **kwargs): # real signature unknown
        pass

    def serviceRecords(self): # real signature unknown; restored from __doc__
        """ QDnsLookup.serviceRecords() -> list-of-QDnsServiceRecord """
        pass

    def setName(self, p_str): # real signature unknown; restored from __doc__
        """ QDnsLookup.setName(str) """
        pass

    def setNameserver(self, QHostAddress): # real signature unknown; restored from __doc__
        """ QDnsLookup.setNameserver(QHostAddress) """
        pass

    def setType(self, QDnsLookup_Type): # real signature unknown; restored from __doc__
        """ QDnsLookup.setType(QDnsLookup.Type) """
        pass

    def textRecords(self): # real signature unknown; restored from __doc__
        """ QDnsLookup.textRecords() -> list-of-QDnsTextRecord """
        pass

    def timerEvent(self, *args, **kwargs): # real signature unknown
        pass

    def type(self): # real signature unknown; restored from __doc__
        """ QDnsLookup.type() -> QDnsLookup.Type """
        pass

    def typeChanged(self, *args, **kwargs): # real signature unknown
        """ QDnsLookup.typeChanged[QDnsLookup.Type] [signal] """
        pass

    def __init__(self, *__args): # real signature unknown; restored from __doc__ with multiple overloads
        pass

    A = 1
    AAAA = 28
    ANY = 255
    CNAME = 5
    InvalidReplyError = 4
    InvalidRequestError = 3
    MX = 15
    NoError = 0
    NotFoundError = 7
    NS = 2
    OperationCancelledError = 2
    PTR = 12
    ResolverError = 1
    ServerFailureError = 5
    ServerRefusedError = 6
    SRV = 33
    TXT = 16


