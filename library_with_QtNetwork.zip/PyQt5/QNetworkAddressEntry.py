# encoding: utf-8
# module PyQt5.QtNetwork
# from C:\Python34\lib\site-packages\PyQt5\QtNetwork.pyd
# by generator 1.136
# no doc

# imports
import PyQt5.QtCore as __PyQt5_QtCore


class QNetworkAddressEntry(): # skipped bases: <class 'sip.simplewrapper'>
    """
    QNetworkAddressEntry()
    QNetworkAddressEntry(QNetworkAddressEntry)
    """
    def broadcast(self): # real signature unknown; restored from __doc__
        """ QNetworkAddressEntry.broadcast() -> QHostAddress """
        return QHostAddress

    def ip(self): # real signature unknown; restored from __doc__
        """ QNetworkAddressEntry.ip() -> QHostAddress """
        return QHostAddress

    def netmask(self): # real signature unknown; restored from __doc__
        """ QNetworkAddressEntry.netmask() -> QHostAddress """
        return QHostAddress

    def prefixLength(self): # real signature unknown; restored from __doc__
        """ QNetworkAddressEntry.prefixLength() -> int """
        return 0

    def setBroadcast(self, QHostAddress): # real signature unknown; restored from __doc__
        """ QNetworkAddressEntry.setBroadcast(QHostAddress) """
        pass

    def setIp(self, QHostAddress): # real signature unknown; restored from __doc__
        """ QNetworkAddressEntry.setIp(QHostAddress) """
        pass

    def setNetmask(self, QHostAddress): # real signature unknown; restored from __doc__
        """ QNetworkAddressEntry.setNetmask(QHostAddress) """
        pass

    def setPrefixLength(self, p_int): # real signature unknown; restored from __doc__
        """ QNetworkAddressEntry.setPrefixLength(int) """
        pass

    def swap(self, QNetworkAddressEntry): # real signature unknown; restored from __doc__
        """ QNetworkAddressEntry.swap(QNetworkAddressEntry) """
        pass

    def __eq__(self, *args, **kwargs): # real signature unknown
        """ Return self==value. """
        pass

    def __ge__(self, *args, **kwargs): # real signature unknown
        """ Return self>=value. """
        pass

    def __gt__(self, *args, **kwargs): # real signature unknown
        """ Return self>value. """
        pass

    def __init__(self, QNetworkAddressEntry=None): # real signature unknown; restored from __doc__ with multiple overloads
        pass

    def __le__(self, *args, **kwargs): # real signature unknown
        """ Return self<=value. """
        pass

    def __lt__(self, *args, **kwargs): # real signature unknown
        """ Return self<value. """
        pass

    def __ne__(self, *args, **kwargs): # real signature unknown
        """ Return self!=value. """
        pass

    __weakref__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """list of weak references to the object (if defined)"""


    __hash__ = None


