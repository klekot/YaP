# encoding: utf-8
# module PyQt5.QtNetwork
# from C:\Python34\lib\site-packages\PyQt5\QtNetwork.pyd
# by generator 1.136
# no doc

# imports
import PyQt5.QtCore as __PyQt5_QtCore


class QLocalServer(__PyQt5_QtCore.QObject):
    """ QLocalServer(QObject parent=None) """
    def childEvent(self, *args, **kwargs): # real signature unknown
        pass

    def close(self): # real signature unknown; restored from __doc__
        """ QLocalServer.close() """
        pass

    def connectNotify(self, *args, **kwargs): # real signature unknown
        pass

    def customEvent(self, *args, **kwargs): # real signature unknown
        pass

    def disconnectNotify(self, *args, **kwargs): # real signature unknown
        pass

    def errorString(self): # real signature unknown; restored from __doc__
        """ QLocalServer.errorString() -> str """
        return ""

    def fullServerName(self): # real signature unknown; restored from __doc__
        """ QLocalServer.fullServerName() -> str """
        return ""

    def hasPendingConnections(self): # real signature unknown; restored from __doc__
        """ QLocalServer.hasPendingConnections() -> bool """
        return False

    def incomingConnection(self, sip_voidptr): # real signature unknown; restored from __doc__
        """ QLocalServer.incomingConnection(sip.voidptr) """
        pass

    def isListening(self): # real signature unknown; restored from __doc__
        """ QLocalServer.isListening() -> bool """
        return False

    def isSignalConnected(self, *args, **kwargs): # real signature unknown
        pass

    def listen(self, *__args): # real signature unknown; restored from __doc__ with multiple overloads
        """
        QLocalServer.listen(str) -> bool
        QLocalServer.listen(sip.voidptr) -> bool
        """
        return False

    def maxPendingConnections(self): # real signature unknown; restored from __doc__
        """ QLocalServer.maxPendingConnections() -> int """
        return 0

    def newConnection(self, *args, **kwargs): # real signature unknown
        """ QLocalServer.newConnection [signal] """
        pass

    def nextPendingConnection(self): # real signature unknown; restored from __doc__
        """ QLocalServer.nextPendingConnection() -> QLocalSocket """
        return QLocalSocket

    def receivers(self, *args, **kwargs): # real signature unknown
        pass

    def removeServer(self, p_str): # real signature unknown; restored from __doc__
        """ QLocalServer.removeServer(str) -> bool """
        return False

    def sender(self, *args, **kwargs): # real signature unknown
        pass

    def senderSignalIndex(self, *args, **kwargs): # real signature unknown
        pass

    def serverError(self): # real signature unknown; restored from __doc__
        """ QLocalServer.serverError() -> QAbstractSocket.SocketError """
        pass

    def serverName(self): # real signature unknown; restored from __doc__
        """ QLocalServer.serverName() -> str """
        return ""

    def setMaxPendingConnections(self, p_int): # real signature unknown; restored from __doc__
        """ QLocalServer.setMaxPendingConnections(int) """
        pass

    def setSocketOptions(self, QLocalServer_SocketOptions): # real signature unknown; restored from __doc__
        """ QLocalServer.setSocketOptions(QLocalServer.SocketOptions) """
        pass

    def socketOptions(self): # real signature unknown; restored from __doc__
        """ QLocalServer.socketOptions() -> QLocalServer.SocketOptions """
        pass

    def timerEvent(self, *args, **kwargs): # real signature unknown
        pass

    def waitForNewConnection(self, int_msecs=0): # real signature unknown; restored from __doc__
        """ QLocalServer.waitForNewConnection(int msecs=0) -> (bool, bool) """
        pass

    def __init__(self, QObject_parent=None): # real signature unknown; restored from __doc__
        pass

    GroupAccessOption = 2
    OtherAccessOption = 4
    UserAccessOption = 1
    WorldAccessOption = 7


