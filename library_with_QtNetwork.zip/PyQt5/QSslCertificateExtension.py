# encoding: utf-8
# module PyQt5.QtNetwork
# from C:\Python34\lib\site-packages\PyQt5\QtNetwork.pyd
# by generator 1.136
# no doc

# imports
import PyQt5.QtCore as __PyQt5_QtCore


class QSslCertificateExtension(): # skipped bases: <class 'sip.simplewrapper'>
    """
    QSslCertificateExtension()
    QSslCertificateExtension(QSslCertificateExtension)
    """
    def isCritical(self): # real signature unknown; restored from __doc__
        """ QSslCertificateExtension.isCritical() -> bool """
        return False

    def isSupported(self): # real signature unknown; restored from __doc__
        """ QSslCertificateExtension.isSupported() -> bool """
        return False

    def name(self): # real signature unknown; restored from __doc__
        """ QSslCertificateExtension.name() -> str """
        return ""

    def oid(self): # real signature unknown; restored from __doc__
        """ QSslCertificateExtension.oid() -> str """
        return ""

    def swap(self, QSslCertificateExtension): # real signature unknown; restored from __doc__
        """ QSslCertificateExtension.swap(QSslCertificateExtension) """
        pass

    def value(self): # real signature unknown; restored from __doc__
        """ QSslCertificateExtension.value() -> QVariant """
        pass

    def __init__(self, QSslCertificateExtension=None): # real signature unknown; restored from __doc__ with multiple overloads
        pass

    __weakref__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """list of weak references to the object (if defined)"""



