# encoding: utf-8
# module PyQt5.QtNetwork
# from C:\Python34\lib\site-packages\PyQt5\QtNetwork.pyd
# by generator 1.136
# no doc

# imports
import PyQt5.QtCore as __PyQt5_QtCore


class QSslCertificate(): # skipped bases: <class 'sip.simplewrapper'>
    """
    QSslCertificate(QIODevice, QSsl.EncodingFormat format=QSsl.Pem)
    QSslCertificate(QByteArray data=QByteArray(), QSsl.EncodingFormat format=QSsl.Pem)
    QSslCertificate(QSslCertificate)
    """
    def clear(self): # real signature unknown; restored from __doc__
        """ QSslCertificate.clear() """
        pass

    def digest(self, QCryptographicHash_Algorithm_algorithm=None): # real signature unknown; restored from __doc__
        """ QSslCertificate.digest(QCryptographicHash.Algorithm algorithm=QCryptographicHash.Md5) -> QByteArray """
        pass

    def effectiveDate(self): # real signature unknown; restored from __doc__
        """ QSslCertificate.effectiveDate() -> QDateTime """
        pass

    def expiryDate(self): # real signature unknown; restored from __doc__
        """ QSslCertificate.expiryDate() -> QDateTime """
        pass

    def extensions(self): # real signature unknown; restored from __doc__
        """ QSslCertificate.extensions() -> list-of-QSslCertificateExtension """
        pass

    def fromData(self, QByteArray, QSsl_EncodingFormat_format=None): # real signature unknown; restored from __doc__
        """ QSslCertificate.fromData(QByteArray, QSsl.EncodingFormat format=QSsl.Pem) -> list-of-QSslCertificate """
        pass

    def fromDevice(self, QIODevice, QSsl_EncodingFormat_format=None): # real signature unknown; restored from __doc__
        """ QSslCertificate.fromDevice(QIODevice, QSsl.EncodingFormat format=QSsl.Pem) -> list-of-QSslCertificate """
        pass

    def fromPath(self, p_str, QSsl_EncodingFormat_format=None, QRegExp_PatternSyntax_syntax=None): # real signature unknown; restored from __doc__
        """ QSslCertificate.fromPath(str, QSsl.EncodingFormat format=QSsl.Pem, QRegExp.PatternSyntax syntax=QRegExp.FixedString) -> list-of-QSslCertificate """
        pass

    def handle(self): # real signature unknown; restored from __doc__
        """ QSslCertificate.handle() -> sip.voidptr """
        pass

    def importPkcs12(self, QIODevice, QSslKey, QSslCertificate, list_of_QSslCertificate_caCertificates=None, QByteArray_passPhrase=None, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
        """ QSslCertificate.importPkcs12(QIODevice, QSslKey, QSslCertificate, list-of-QSslCertificate caCertificates=None, QByteArray passPhrase=QByteArray()) -> bool """
        pass

    def isBlacklisted(self): # real signature unknown; restored from __doc__
        """ QSslCertificate.isBlacklisted() -> bool """
        return False

    def isNull(self): # real signature unknown; restored from __doc__
        """ QSslCertificate.isNull() -> bool """
        return False

    def isSelfSigned(self): # real signature unknown; restored from __doc__
        """ QSslCertificate.isSelfSigned() -> bool """
        return False

    def issuerInfo(self, *__args): # real signature unknown; restored from __doc__ with multiple overloads
        """
        QSslCertificate.issuerInfo(QSslCertificate.SubjectInfo) -> list-of-str
        QSslCertificate.issuerInfo(QByteArray) -> list-of-str
        """
        pass

    def issuerInfoAttributes(self): # real signature unknown; restored from __doc__
        """ QSslCertificate.issuerInfoAttributes() -> list-of-QByteArray """
        pass

    def publicKey(self): # real signature unknown; restored from __doc__
        """ QSslCertificate.publicKey() -> QSslKey """
        return QSslKey

    def serialNumber(self): # real signature unknown; restored from __doc__
        """ QSslCertificate.serialNumber() -> QByteArray """
        pass

    def subjectAlternativeNames(self): # real signature unknown; restored from __doc__
        """ QSslCertificate.subjectAlternativeNames() -> dict-of-QSsl.AlternativeNameEntryType-list-of-str """
        pass

    def subjectInfo(self, *__args): # real signature unknown; restored from __doc__ with multiple overloads
        """
        QSslCertificate.subjectInfo(QSslCertificate.SubjectInfo) -> list-of-str
        QSslCertificate.subjectInfo(QByteArray) -> list-of-str
        """
        pass

    def subjectInfoAttributes(self): # real signature unknown; restored from __doc__
        """ QSslCertificate.subjectInfoAttributes() -> list-of-QByteArray """
        pass

    def swap(self, QSslCertificate): # real signature unknown; restored from __doc__
        """ QSslCertificate.swap(QSslCertificate) """
        pass

    def toDer(self): # real signature unknown; restored from __doc__
        """ QSslCertificate.toDer() -> QByteArray """
        pass

    def toPem(self): # real signature unknown; restored from __doc__
        """ QSslCertificate.toPem() -> QByteArray """
        pass

    def toText(self): # real signature unknown; restored from __doc__
        """ QSslCertificate.toText() -> str """
        return ""

    def verify(self, list_of_QSslCertificate, str_hostName=None, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
        """ QSslCertificate.verify(list-of-QSslCertificate, str hostName=QString()) -> list-of-QSslError """
        pass

    def version(self): # real signature unknown; restored from __doc__
        """ QSslCertificate.version() -> QByteArray """
        pass

    def __eq__(self, *args, **kwargs): # real signature unknown
        """ Return self==value. """
        pass

    def __ge__(self, *args, **kwargs): # real signature unknown
        """ Return self>=value. """
        pass

    def __gt__(self, *args, **kwargs): # real signature unknown
        """ Return self>value. """
        pass

    def __hash__(self, *args, **kwargs): # real signature unknown
        """ Return hash(self). """
        pass

    def __init__(self, *__args): # real signature unknown; restored from __doc__ with multiple overloads
        pass

    def __le__(self, *args, **kwargs): # real signature unknown
        """ Return self<=value. """
        pass

    def __lt__(self, *args, **kwargs): # real signature unknown
        """ Return self<value. """
        pass

    def __ne__(self, *args, **kwargs): # real signature unknown
        """ Return self!=value. """
        pass

    __weakref__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """list of weak references to the object (if defined)"""


    CommonName = 1
    CountryName = 4
    DistinguishedNameQualifier = 6
    EmailAddress = 8
    LocalityName = 2
    Organization = 0
    OrganizationalUnitName = 3
    SerialNumber = 7
    StateOrProvinceName = 5


