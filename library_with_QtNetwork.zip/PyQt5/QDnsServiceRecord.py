# encoding: utf-8
# module PyQt5.QtNetwork
# from C:\Python34\lib\site-packages\PyQt5\QtNetwork.pyd
# by generator 1.136
# no doc

# imports
import PyQt5.QtCore as __PyQt5_QtCore


class QDnsServiceRecord(): # skipped bases: <class 'sip.simplewrapper'>
    """
    QDnsServiceRecord()
    QDnsServiceRecord(QDnsServiceRecord)
    """
    def name(self): # real signature unknown; restored from __doc__
        """ QDnsServiceRecord.name() -> str """
        return ""

    def port(self): # real signature unknown; restored from __doc__
        """ QDnsServiceRecord.port() -> int """
        return 0

    def priority(self): # real signature unknown; restored from __doc__
        """ QDnsServiceRecord.priority() -> int """
        return 0

    def swap(self, QDnsServiceRecord): # real signature unknown; restored from __doc__
        """ QDnsServiceRecord.swap(QDnsServiceRecord) """
        pass

    def target(self): # real signature unknown; restored from __doc__
        """ QDnsServiceRecord.target() -> str """
        return ""

    def timeToLive(self): # real signature unknown; restored from __doc__
        """ QDnsServiceRecord.timeToLive() -> int """
        return 0

    def weight(self): # real signature unknown; restored from __doc__
        """ QDnsServiceRecord.weight() -> int """
        return 0

    def __init__(self, QDnsServiceRecord=None): # real signature unknown; restored from __doc__ with multiple overloads
        pass

    __weakref__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """list of weak references to the object (if defined)"""



