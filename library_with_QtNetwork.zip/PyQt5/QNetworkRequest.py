# encoding: utf-8
# module PyQt5.QtNetwork
# from C:\Python34\lib\site-packages\PyQt5\QtNetwork.pyd
# by generator 1.136
# no doc

# imports
import PyQt5.QtCore as __PyQt5_QtCore


class QNetworkRequest(): # skipped bases: <class 'sip.simplewrapper'>
    """
    QNetworkRequest(QUrl url=QUrl())
    QNetworkRequest(QNetworkRequest)
    """
    def attribute(self, QNetworkRequest_Attribute, QVariant_defaultValue=None): # real signature unknown; restored from __doc__
        """ QNetworkRequest.attribute(QNetworkRequest.Attribute, QVariant defaultValue=None) -> QVariant """
        pass

    def hasRawHeader(self, QByteArray): # real signature unknown; restored from __doc__
        """ QNetworkRequest.hasRawHeader(QByteArray) -> bool """
        return False

    def header(self, QNetworkRequest_KnownHeaders): # real signature unknown; restored from __doc__
        """ QNetworkRequest.header(QNetworkRequest.KnownHeaders) -> QVariant """
        pass

    def originatingObject(self): # real signature unknown; restored from __doc__
        """ QNetworkRequest.originatingObject() -> QObject """
        pass

    def priority(self): # real signature unknown; restored from __doc__
        """ QNetworkRequest.priority() -> QNetworkRequest.Priority """
        pass

    def rawHeader(self, QByteArray): # real signature unknown; restored from __doc__
        """ QNetworkRequest.rawHeader(QByteArray) -> QByteArray """
        pass

    def rawHeaderList(self): # real signature unknown; restored from __doc__
        """ QNetworkRequest.rawHeaderList() -> list-of-QByteArray """
        pass

    def setAttribute(self, QNetworkRequest_Attribute, QVariant): # real signature unknown; restored from __doc__
        """ QNetworkRequest.setAttribute(QNetworkRequest.Attribute, QVariant) """
        pass

    def setHeader(self, QNetworkRequest_KnownHeaders, QVariant): # real signature unknown; restored from __doc__
        """ QNetworkRequest.setHeader(QNetworkRequest.KnownHeaders, QVariant) """
        pass

    def setOriginatingObject(self, QObject): # real signature unknown; restored from __doc__
        """ QNetworkRequest.setOriginatingObject(QObject) """
        pass

    def setPriority(self, QNetworkRequest_Priority): # real signature unknown; restored from __doc__
        """ QNetworkRequest.setPriority(QNetworkRequest.Priority) """
        pass

    def setRawHeader(self, QByteArray, QByteArray_1): # real signature unknown; restored from __doc__
        """ QNetworkRequest.setRawHeader(QByteArray, QByteArray) """
        pass

    def setSslConfiguration(self, QSslConfiguration): # real signature unknown; restored from __doc__
        """ QNetworkRequest.setSslConfiguration(QSslConfiguration) """
        pass

    def setUrl(self, QUrl): # real signature unknown; restored from __doc__
        """ QNetworkRequest.setUrl(QUrl) """
        pass

    def sslConfiguration(self): # real signature unknown; restored from __doc__
        """ QNetworkRequest.sslConfiguration() -> QSslConfiguration """
        return QSslConfiguration

    def swap(self, QNetworkRequest): # real signature unknown; restored from __doc__
        """ QNetworkRequest.swap(QNetworkRequest) """
        pass

    def url(self): # real signature unknown; restored from __doc__
        """ QNetworkRequest.url() -> QUrl """
        pass

    def __eq__(self, *args, **kwargs): # real signature unknown
        """ Return self==value. """
        pass

    def __ge__(self, *args, **kwargs): # real signature unknown
        """ Return self>=value. """
        pass

    def __gt__(self, *args, **kwargs): # real signature unknown
        """ Return self>value. """
        pass

    def __init__(self, *__args): # real signature unknown; restored from __doc__ with multiple overloads
        pass

    def __le__(self, *args, **kwargs): # real signature unknown
        """ Return self<=value. """
        pass

    def __lt__(self, *args, **kwargs): # real signature unknown
        """ Return self<value. """
        pass

    def __ne__(self, *args, **kwargs): # real signature unknown
        """ Return self!=value. """
        pass

    __weakref__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """list of weak references to the object (if defined)"""


    AlwaysCache = 3
    AlwaysNetwork = 0
    AuthenticationReuseAttribute = 12
    Automatic = 0
    BackgroundRequestAttribute = 17
    CacheLoadControlAttribute = 4
    CacheSaveControlAttribute = 5
    ConnectionEncryptedAttribute = 3
    ContentDispositionHeader = 6
    ContentLengthHeader = 1
    ContentTypeHeader = 0
    CookieHeader = 4
    CookieLoadControlAttribute = 11
    CookieSaveControlAttribute = 13
    CustomVerbAttribute = 10
    DoNotBufferUploadDataAttribute = 7
    HighPriority = 1
    HttpPipeliningAllowedAttribute = 8
    HttpPipeliningWasUsedAttribute = 9
    HttpReasonPhraseAttribute = 1
    HttpStatusCodeAttribute = 0
    LastModifiedHeader = 3
    LocationHeader = 2
    LowPriority = 5
    Manual = 1
    NormalPriority = 3
    PreferCache = 2
    PreferNetwork = 1
    RedirectionTargetAttribute = 2
    ServerHeader = 8
    SetCookieHeader = 5
    SourceIsFromCacheAttribute = 6
    SpdyAllowedAttribute = 18
    SpdyWasUsedAttribute = 19
    User = 1000
    UserAgentHeader = 7
    UserMax = 32767
    __hash__ = None


