# encoding: utf-8
# module PyQt5.QtNetwork
# from C:\Python34\lib\site-packages\PyQt5\QtNetwork.pyd
# by generator 1.136
# no doc

# imports
import PyQt5.QtCore as __PyQt5_QtCore


class QSslCipher(): # skipped bases: <class 'sip.simplewrapper'>
    """
    QSslCipher()
    QSslCipher(str)
    QSslCipher(str, QSsl.SslProtocol)
    QSslCipher(QSslCipher)
    """
    def authenticationMethod(self): # real signature unknown; restored from __doc__
        """ QSslCipher.authenticationMethod() -> str """
        return ""

    def encryptionMethod(self): # real signature unknown; restored from __doc__
        """ QSslCipher.encryptionMethod() -> str """
        return ""

    def isNull(self): # real signature unknown; restored from __doc__
        """ QSslCipher.isNull() -> bool """
        return False

    def keyExchangeMethod(self): # real signature unknown; restored from __doc__
        """ QSslCipher.keyExchangeMethod() -> str """
        return ""

    def name(self): # real signature unknown; restored from __doc__
        """ QSslCipher.name() -> str """
        return ""

    def protocol(self): # real signature unknown; restored from __doc__
        """ QSslCipher.protocol() -> QSsl.SslProtocol """
        pass

    def protocolString(self): # real signature unknown; restored from __doc__
        """ QSslCipher.protocolString() -> str """
        return ""

    def supportedBits(self): # real signature unknown; restored from __doc__
        """ QSslCipher.supportedBits() -> int """
        return 0

    def swap(self, QSslCipher): # real signature unknown; restored from __doc__
        """ QSslCipher.swap(QSslCipher) """
        pass

    def usedBits(self): # real signature unknown; restored from __doc__
        """ QSslCipher.usedBits() -> int """
        return 0

    def __eq__(self, *args, **kwargs): # real signature unknown
        """ Return self==value. """
        pass

    def __ge__(self, *args, **kwargs): # real signature unknown
        """ Return self>=value. """
        pass

    def __gt__(self, *args, **kwargs): # real signature unknown
        """ Return self>value. """
        pass

    def __init__(self, *__args): # real signature unknown; restored from __doc__ with multiple overloads
        pass

    def __le__(self, *args, **kwargs): # real signature unknown
        """ Return self<=value. """
        pass

    def __lt__(self, *args, **kwargs): # real signature unknown
        """ Return self<value. """
        pass

    def __ne__(self, *args, **kwargs): # real signature unknown
        """ Return self!=value. """
        pass

    __weakref__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """list of weak references to the object (if defined)"""


    __hash__ = None


