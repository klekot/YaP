# encoding: utf-8
# module PyQt5.QtNetwork
# from C:\Python34\lib\site-packages\PyQt5\QtNetwork.pyd
# by generator 1.136
# no doc

# imports
import PyQt5.QtCore as __PyQt5_QtCore


class QHttpPart(): # skipped bases: <class 'sip.simplewrapper'>
    """
    QHttpPart()
    QHttpPart(QHttpPart)
    """
    def setBody(self, QByteArray): # real signature unknown; restored from __doc__
        """ QHttpPart.setBody(QByteArray) """
        pass

    def setBodyDevice(self, QIODevice): # real signature unknown; restored from __doc__
        """ QHttpPart.setBodyDevice(QIODevice) """
        pass

    def setHeader(self, QNetworkRequest_KnownHeaders, QVariant): # real signature unknown; restored from __doc__
        """ QHttpPart.setHeader(QNetworkRequest.KnownHeaders, QVariant) """
        pass

    def setRawHeader(self, QByteArray, QByteArray_1): # real signature unknown; restored from __doc__
        """ QHttpPart.setRawHeader(QByteArray, QByteArray) """
        pass

    def swap(self, QHttpPart): # real signature unknown; restored from __doc__
        """ QHttpPart.swap(QHttpPart) """
        pass

    def __eq__(self, *args, **kwargs): # real signature unknown
        """ Return self==value. """
        pass

    def __ge__(self, *args, **kwargs): # real signature unknown
        """ Return self>=value. """
        pass

    def __gt__(self, *args, **kwargs): # real signature unknown
        """ Return self>value. """
        pass

    def __init__(self, QHttpPart=None): # real signature unknown; restored from __doc__ with multiple overloads
        pass

    def __le__(self, *args, **kwargs): # real signature unknown
        """ Return self<=value. """
        pass

    def __lt__(self, *args, **kwargs): # real signature unknown
        """ Return self<value. """
        pass

    def __ne__(self, *args, **kwargs): # real signature unknown
        """ Return self!=value. """
        pass

    __weakref__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """list of weak references to the object (if defined)"""


    __hash__ = None


