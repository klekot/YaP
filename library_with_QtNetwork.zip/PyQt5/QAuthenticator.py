# encoding: utf-8
# module PyQt5.QtNetwork
# from C:\Python34\lib\site-packages\PyQt5\QtNetwork.pyd
# by generator 1.136
# no doc

# imports
import PyQt5.QtCore as __PyQt5_QtCore


class QAuthenticator(): # skipped bases: <class 'sip.simplewrapper'>
    """
    QAuthenticator()
    QAuthenticator(QAuthenticator)
    """
    def isNull(self): # real signature unknown; restored from __doc__
        """ QAuthenticator.isNull() -> bool """
        return False

    def option(self, p_str): # real signature unknown; restored from __doc__
        """ QAuthenticator.option(str) -> QVariant """
        pass

    def options(self): # real signature unknown; restored from __doc__
        """ QAuthenticator.options() -> dict-of-str-object """
        pass

    def password(self): # real signature unknown; restored from __doc__
        """ QAuthenticator.password() -> str """
        return ""

    def realm(self): # real signature unknown; restored from __doc__
        """ QAuthenticator.realm() -> str """
        return ""

    def setOption(self, p_str, QVariant): # real signature unknown; restored from __doc__
        """ QAuthenticator.setOption(str, QVariant) """
        pass

    def setPassword(self, p_str): # real signature unknown; restored from __doc__
        """ QAuthenticator.setPassword(str) """
        pass

    def setUser(self, p_str): # real signature unknown; restored from __doc__
        """ QAuthenticator.setUser(str) """
        pass

    def user(self): # real signature unknown; restored from __doc__
        """ QAuthenticator.user() -> str """
        return ""

    def __eq__(self, *args, **kwargs): # real signature unknown
        """ Return self==value. """
        pass

    def __ge__(self, *args, **kwargs): # real signature unknown
        """ Return self>=value. """
        pass

    def __gt__(self, *args, **kwargs): # real signature unknown
        """ Return self>value. """
        pass

    def __init__(self, QAuthenticator=None): # real signature unknown; restored from __doc__ with multiple overloads
        pass

    def __le__(self, *args, **kwargs): # real signature unknown
        """ Return self<=value. """
        pass

    def __lt__(self, *args, **kwargs): # real signature unknown
        """ Return self<value. """
        pass

    def __ne__(self, *args, **kwargs): # real signature unknown
        """ Return self!=value. """
        pass

    __weakref__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """list of weak references to the object (if defined)"""


    __hash__ = None


