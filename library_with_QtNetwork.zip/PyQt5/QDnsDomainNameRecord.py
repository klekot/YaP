# encoding: utf-8
# module PyQt5.QtNetwork
# from C:\Python34\lib\site-packages\PyQt5\QtNetwork.pyd
# by generator 1.136
# no doc

# imports
import PyQt5.QtCore as __PyQt5_QtCore


class QDnsDomainNameRecord(): # skipped bases: <class 'sip.simplewrapper'>
    """
    QDnsDomainNameRecord()
    QDnsDomainNameRecord(QDnsDomainNameRecord)
    """
    def name(self): # real signature unknown; restored from __doc__
        """ QDnsDomainNameRecord.name() -> str """
        return ""

    def swap(self, QDnsDomainNameRecord): # real signature unknown; restored from __doc__
        """ QDnsDomainNameRecord.swap(QDnsDomainNameRecord) """
        pass

    def timeToLive(self): # real signature unknown; restored from __doc__
        """ QDnsDomainNameRecord.timeToLive() -> int """
        return 0

    def value(self): # real signature unknown; restored from __doc__
        """ QDnsDomainNameRecord.value() -> str """
        return ""

    def __init__(self, QDnsDomainNameRecord=None): # real signature unknown; restored from __doc__ with multiple overloads
        pass

    __weakref__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """list of weak references to the object (if defined)"""



